module.exports = {
  content: ["./src/**/*.{html,js}", "./*.hbs", "./**/*.hbs"],
  theme: {
    extend: {},
  },
  plugins: [],
}
